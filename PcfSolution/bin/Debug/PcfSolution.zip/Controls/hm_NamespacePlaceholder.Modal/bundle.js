/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./Modal/Modal.tsx":
/*!*************************!*\
  !*** ./Modal/Modal.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Modal)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _ModalComponents_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ModalComponents/ConfirmationModal */ \"./Modal/ModalComponents/ConfirmationModal.tsx\");\n/* harmony import */ var _ModalComponents_DeleteModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ModalComponents/DeleteModal */ \"./Modal/ModalComponents/DeleteModal.tsx\");\n\"use client\";\n\n\n\n\nfunction Modal(props) {\n  var _a, _b;\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      height: \"\".concat(props.containerHeight, \"px\"),\n      width: \"\".concat(props.containerWidth, \"px\")\n    }\n  }, ((_a = props.modalType) === null || _a === void 0 ? void 0 : _a.toLowerCase()) == \"confirm\" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ModalComponents_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__[\"default\"], Object.assign({}, props)) : ((_b = props.modalType) === null || _b === void 0 ? void 0 : _b.toLowerCase()) == \"delete\" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ModalComponents_DeleteModal__WEBPACK_IMPORTED_MODULE_2__[\"default\"], Object.assign({}, props)) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ModalComponents_ConfirmationModal__WEBPACK_IMPORTED_MODULE_1__[\"default\"], Object.assign({}, props)));\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Modal/Modal.tsx?\n}");

/***/ }),

/***/ "./Modal/ModalComponents/ConfirmationModal.tsx":
/*!*****************************************************!*\
  !*** ./Modal/ModalComponents/ConfirmationModal.tsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ConfirmationModal)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _TextInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TextInput */ \"./Modal/ModalComponents/TextInput.tsx\");\n/* eslint-disable */\n\"use client\";\n\n\n\n\nfunction ConfirmationModal(props) {\n  var [inputText, setInputText] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');\n  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {\n    props.onInputTextChange(inputText);\n  }, [inputText]);\n  var confirmationButtonClasses = \"inline-flex w-full justify-center rounded-md  bg-green-500 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-green-600 flex-1 \".concat(props.requiredConfirmationText != null && inputText != props.requiredConfirmationText ? 'disabled' : '');\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      backgroundColor: \"RGBA(0, 0, 0, 0.49)\",\n      width: \"100%\",\n      height: props.containerHeight\n    },\n    className: \"all-centered-container\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      height: \"fit-content\",\n      backgroundColor: \"white\",\n      borderRadius: \"10px\",\n      display: \"flex\",\n      flexDirection: \"row\",\n      gap: \".8rem\",\n      maxWidth: '500px'\n    },\n    className: \"p-4\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    xmlns: \"http://www.w3.org/2000/svg\",\n    width: \"35\",\n    height: \"35\",\n    viewBox: \"0 0 110 110\",\n    fill: \"none\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"circle\", {\n    cx: \"55\",\n    cy: \"55\",\n    r: \"55\",\n    fill: \"#52ff0454\"\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M55.001 41.8631V55.1263M22.0784 67.0667C19.0137 72.3719 22.8464 79 28.9722 79H81.0297C87.152 79 90.9847 72.3719 87.9235 67.0667L61.8983 21.979C58.8336 16.6737 51.1683 16.6737 48.1036 21.979L22.0784 67.0667ZM55.001 65.7368H55.0257V65.7651H55.001V65.7368Z\",\n    stroke: \"green\",\n    strokeWidth: \"5\",\n    strokeLinecap: \"round\",\n    strokeLinejoin: \"round\"\n  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"flex flex-col\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"text-semibold w-full text-left\",\n    style: {\n      whiteSpace: 'pre-wrap'\n    }\n  }, props.modalHeader), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"text-left\",\n    style: {\n      whiteSpace: 'pre-wrap'\n    }\n  }, props.modalText), props.includeTextInput ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_TextInput__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n    placeholder: props.inputTextPlaceholder,\n    onInputTextChange: setInputText\n  }) : null, props.requiredConfirmationText ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    style: {\n      fontWeight: 200,\n      fontSize: 12,\n      textAlign: 'start',\n      marginTop: '4px',\n      textWrap: 'wrap',\n      whiteSpace: 'pre-wrap'\n    }\n  }, \"Please type \", props.requiredConfirmationText, \" to confirm\") : null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      maxWidth: \"\".concat(props.containerWidth / 2, \"px\")\n    },\n    className: \"flex gap-1 items-end w-full flex-row-reverse mt-2\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: \"mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 flex-1\",\n    onClick: props.OnCancel\n  }, \"Cancel\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: confirmationButtonClasses,\n    onClick: props.OnConfirm\n  }, props.confirmText)))));\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Modal/ModalComponents/ConfirmationModal.tsx?\n}");

/***/ }),

/***/ "./Modal/ModalComponents/DeleteModal.tsx":
/*!***********************************************!*\
  !*** ./Modal/ModalComponents/DeleteModal.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ DeleteModal)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _TextInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TextInput */ \"./Modal/ModalComponents/TextInput.tsx\");\n/* eslint-disable */\n\"use client\";\n\n\n\n\nfunction DeleteModal(props) {\n  var [inputText, setInputText] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');\n  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {\n    props.onInputTextChange(inputText);\n  }, [inputText]);\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      backgroundColor: \"RGBA(0, 0, 0, 0.49)\",\n      width: \"100%\",\n      height: props.containerHeight\n    },\n    className: \"all-centered-container\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      height: \"fit-content\",\n      backgroundColor: \"white\",\n      borderRadius: \"10px\",\n      display: \"flex\",\n      flexDirection: \"row\",\n      gap: \".8rem\",\n      maxWidth: '500px'\n    },\n    className: \"p-4\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    xmlns: \"http://www.w3.org/2000/svg\",\n    width: \"35\",\n    height: \"35\",\n    viewBox: \"0 0 110 110\",\n    fill: \"none\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"circle\", {\n    cx: \"55\",\n    cy: \"55\",\n    r: \"55\",\n    fill: \"#FEE2E2\"\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M55.001 41.8631V55.1263M22.0784 67.0667C19.0137 72.3719 22.8464 79 28.9722 79H81.0297C87.152 79 90.9847 72.3719 87.9235 67.0667L61.8983 21.979C58.8336 16.6737 51.1683 16.6737 48.1036 21.979L22.0784 67.0667ZM55.001 65.7368H55.0257V65.7651H55.001V65.7368Z\",\n    stroke: \"#FE0000\",\n    strokeWidth: \"5\",\n    strokeLinecap: \"round\",\n    strokeLinejoin: \"round\"\n  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"flex flex-col\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"text-semibold w-full text-left\",\n    style: {\n      whiteSpace: 'pre-wrap'\n    }\n  }, props.modalHeader), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"text-left\",\n    style: {\n      whiteSpace: 'pre-wrap'\n    }\n  }, props.modalText), props.includeTextInput ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_TextInput__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n    placeholder: props.inputTextPlaceholder,\n    onInputTextChange: setInputText\n  }) : null, props.requiredConfirmationText ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    style: {\n      fontWeight: 200,\n      fontSize: 12,\n      textAlign: 'start',\n      marginTop: '4px',\n      textWrap: 'wrap',\n      whiteSpace: 'pre-wrap'\n    }\n  }, \"Please type \", props.requiredConfirmationText, \" to delete\") : null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"flex gap-1 items-end w-full flex-row-reverse mt-2\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: \"mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 flex-1 \",\n    onClick: props.OnCancel\n  }, \"Cancel\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: \"inline-flex w-full justify-center rounded-md  bg-red-500 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-600 flex-1 \".concat(props.requiredConfirmationText != null && inputText != props.requiredConfirmationText ? 'disabled' : '', \" \"),\n    onClick: props.OnConfirm\n  }, props.confirmText)))));\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Modal/ModalComponents/DeleteModal.tsx?\n}");

/***/ }),

/***/ "./Modal/ModalComponents/TextInput.tsx":
/*!*********************************************!*\
  !*** ./Modal/ModalComponents/TextInput.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar TextInput = props => {\n  var _a;\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"mt-2\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n    placeholder: (_a = props.placeholder) !== null && _a !== void 0 ? _a : \"Please input reason\",\n    className: \"block rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6\",\n    style: {\n      width: '-webkit-fill-available'\n    },\n    onChange: e => {\n      props.onInputTextChange(e.target.value);\n    }\n  }));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextInput);\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Modal/ModalComponents/TextInput.tsx?\n}");

/***/ }),

/***/ "./Modal/index.ts":
/*!************************!*\
  !*** ./Modal/index.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Modal: () => (/* binding */ Modal)\n/* harmony export */ });\n/* harmony import */ var _Modal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Modal */ \"./Modal/Modal.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass Modal {\n  constructor() {\n    this.state = {\n      outputText: \"\"\n    };\n    this.onInputTextChange = newText => {\n      this.state = Object.assign(Object.assign({}, this.state), {\n        outputText: newText\n      });\n      this.notifyOutputChanged();\n    };\n  }\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.context = context;\n  }\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f;\n    var props = {\n      containerHeight: (_a = context.parameters.containerHeight.raw) !== null && _a !== void 0 ? _a : 500,\n      modalHeader: (_b = context.parameters.dialogHeader.raw) !== null && _b !== void 0 ? _b : \"\",\n      modalText: (_c = context.parameters.dialogText.raw) !== null && _c !== void 0 ? _c : \"\",\n      confirmText: (_d = context.parameters.confirmText.raw) !== null && _d !== void 0 ? _d : \"\",\n      OnCancel: context.events.OnCancel,\n      OnConfirm: context.events.OnConfirm,\n      modalType: context.parameters.modalType.raw,\n      containerWidth: (_e = context.parameters.containerWidth.raw) !== null && _e !== void 0 ? _e : 500,\n      includeTextInput: context.parameters.includeTextInput.raw,\n      inputTextPlaceholder: (_f = context.parameters.textInputPlaceholder.raw) !== null && _f !== void 0 ? _f : \"Please input reason\",\n      onInputTextChange: this.onInputTextChange,\n      requiredConfirmationText: context.parameters.requiredConfirmText.raw\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_Modal__WEBPACK_IMPORTED_MODULE_0__[\"default\"], props);\n  }\n  getOutputs() {\n    return {\n      outputText: this.state.outputText\n    };\n  }\n  destroy() {}\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Modal/index.ts?\n}");

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./Modal/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('NamespacePlaceholder.Modal', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Modal);
} else {
	var NamespacePlaceholder = NamespacePlaceholder || {};
	NamespacePlaceholder.Modal = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Modal;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}